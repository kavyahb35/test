<?php 
	
	define('AppId','2eb21076');
	define('AppKey','abb1a58647520749d8b6279132bad442');
	define('Api_Url','http://ewa.wilcom.com/1.4/');
 ?>

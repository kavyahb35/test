<?php 
   include_once('constant.php');
   ini_set('session.cache_limiter','public');
   session_cache_limiter(false);
   error_reporting(0);
   if($_POST){      
      $ddlFontList = $_POST['ddlFontList'];
      $ddlColorList = $_POST['ddlColorList'];
      $heights = $_POST['heights'];
      
      if($heights < 5 || $heights > 50) {
			$error = 'Please enter the number between 5 to 50';
	   } else{      
			  $contents = $_POST['contents'];
			  $dpTrueviewDPI = $_POST['dpTrueviewDPI'];
			  $AppId = AppId;
			  $AppKey = AppKey; 
			  $RequestXml = 
'<?xml version="1.0" encoding="utf-8"?>
 <xml xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
   <recipe>
    <decorations>
      <lettering>
        <simple_lettering text="'.$contents.'" alphabet_name="'.$ddlFontList.'" height="'.$heights.'" />
        <thread color="'.$ddlColorList.'" />
      </lettering>
    </decorations>
    <output trueview_file="ResultImage.png" dpi="'.$dpTrueviewDPI.'" />
  </recipe>
</xml>
';
				$recipe = $_POST['recipe'];
				$data = 'AppId='.$AppId.'&AppKey='.$AppKey.'&RequestXml='.$RequestXml;
				$curl = curl_init();
				curl_setopt_array($curl, array(
				CURLOPT_URL => Api_Url."api/newdesigntrueview",
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "POST",
				CURLOPT_POSTFIELDS => $data,
				CURLOPT_HTTPHEADER => array(
				"Content-Type: application/x-www-form-urlencoded"
				),
				));
				$response = curl_exec($curl);
				$err = curl_error($curl);
				$xml = simplexml_load_string($response);
				$json = json_encode($xml);
				$array = json_decode($json,TRUE);
				
				$fileheight = $array['design_info']['@attributes']['height'];
				$filewidth = $array['design_info']['@attributes']['width'];
				$filename = $array['files']['file']['@attributes']['filename'];
				$filecontents = $array['files']['file']['@attributes']['filecontents'];
				$filecontentmode = $array['files']['file']['@attributes']['filecontentmode'];
				if($recipe=='1'){
				$recipe_post =  $RequestXml;	
				}
				function ConvertmmToPixcel($mm,$DPI)
				{
					$DPI ='96';
					return round($mm * ($DPI / 25.4));
				}
				$height = ConvertmmToPixcel($fileheight,$dpTrueviewDPI);		
				$width = ConvertmmToPixcel($filewidth,$dpTrueviewDPI);
			}
		} ?>
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta name="viewport" content="width=device-width">
      <title>
         Web Lettering Concept
      </title>
      <link rel='SHORTCUT ICON' href='assets/image/favicon.ico' type='image/x-icon' />
      <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
      <link rel="stylesheet" type="text/css" href="assets/css/style.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   </head>
   <body cz-shortcut-listen="true">
      <div class="ewa-page-container">
         <div class="ewa-logo-container">
            <div>
               <div class="ewa-logo-container-header">
                  <h1>API: Web Lettering Concept</h1>
                  <span><span id="lbVersion">(1.4.0.23450)</span></span>
               </div>
               <div class="ewa-logo-container-logo">
                  <img src="assets/image/wilcom-logo.png" alt="Wilcom">
               </div>
            </div>
         </div>
         <form method="Post" id="form1">
            <div class="aspNetHidden"></div>
            <div class="ewa-designarea-container">
               <div>
                  <div class="ewa-toolset-container" id="ewa-toolset-container">
                     <h3>Input values:</h3>
                     <!-- ADD TOOLS / FIELD SETS HERE -->
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                           Font
                        </div>
                        <div class="ewa-field valuecolumn">
                           <select name="ddlFontList" id="ddlFontList" >
                              <option value="2 Col Plain Script" <?php if($_POST['ddlFontList']=='2 Col Plain Script'){ echo 'selected=selected';}?>>2 Col Plain Script</option>
                              <option value="01Monogram Ornaments Alphabet" <?php if($_POST['ddlFontList']=='01Monogram Ornaments Alphabet'){ echo 'selected=selected';}?>>01Monogram Ornaments Alphabet</option>
                              <option value="2 Col Arial Shadow" <?php if($_POST['ddlFontList']=='2 Col Arial Shadow'){ echo 'selected=selected';}?>>2 Col Arial Shadow</option>
                              <option value="3D Block2" <?php if($_POST['ddlFontList']=='3D Block2'){ echo 'selected=selected';}?>>3D Block2</option>
                              <option value="3D Brush Script" <?php if($_POST['ddlFontList']=='3D Brush Script'){ echo 'selected=selected';}?>>3D Brush Script</option>
                              <option value="3D Emphatic" <?php if($_POST['ddlFontList']=='3D Emphatic'){ echo 'selected=selected';}?>>3D Emphatic</option>
                              <option value="3D Futuro" <?php if($_POST['ddlFontList']=='3D Futuro'){ echo 'selected=selected';}?>>3D Futuro</option>
                              <option value="3D London" <?php if($_POST['ddlFontList']=='3D London'){ echo 'selected=selected';}?>>3D London</option>
                              <option value="3D Monoglyceride" <?php if($_POST['ddlFontList']=='3D Monoglyceride'){ echo 'selected=selected';}?>>3D Monoglyceride</option>
                              <option value="3D Sofachrome" <?php if($_POST['ddlFontList']=='3D Sofachrome'){ echo 'selected=selected';}?>>3D Sofachrome</option>
                              <option value="Adelle" <?php if($_POST['ddlFontList']=='Adelle'){ echo 'selected=selected';}?>>Adelle</option>
                              <option value="Advent" <?php if($_POST['ddlFontList']=='Advent'){ echo 'selected=selected';}?>>Advent</option>
                              <option value="AGATHA" <?php if($_POST['ddlFontList']=='AGATHA'){ echo 'selected=selected';}?>>AGATHA</option>
                              <option value="Algerian" <?php if($_POST['ddlFontList']=='Algerian'){ echo 'selected=selected';}?>>Algerian</option>
                              <option value="Anaconda" <?php if($_POST['ddlFontList']=='Anaconda'){ echo 'selected=selected';}?>>Anaconda</option>
                              <option value="Angle Block" <?php if($_POST['ddlFontList']=='Angle Block'){ echo 'selected=selected';}?>>Angle Block</option>
                              <option value="Antique Rose" <?php if($_POST['ddlFontList']=='Antique Rose'){ echo 'selected=selected';}?>>Antique Rose</option>
                              <option value="Architect" <?php if($_POST['ddlFontList']=='Architect'){ echo 'selected=selected';}?>>Architect</option>
                              <option value="Arial Rounded" <?php if($_POST['ddlFontList']=='Arial Rounded'){ echo 'selected=selected';}?>>Arial Rounded</option>
                              <option value="Arnold" <?php if($_POST['ddlFontList']=='Arnold'){ echo 'selected=selected';}?>>Arnold</option>
                              <option value="Art Block" <?php if($_POST['ddlFontList']=='Art Block'){ echo 'selected=selected';}?>>Art Block</option>
                              <option value="Athletica" <?php if($_POST['ddlFontList']=='Athletica'){ echo 'selected=selected';}?>>Athletica</option>
                              <option value="Avant Garde" <?php if($_POST['ddlFontList']=='Avant Garde'){ echo 'selected=selected';}?>>Avant Garde</option>
                              <option value="Ballantines Script" <?php if($_POST['ddlFontList']=='Ballantines Script'){ echo 'selected=selected';}?>>Ballantines Script</option>
                              <option value="Bauhaus" <?php if($_POST['ddlFontList']=='Bauhaus'){ echo 'selected=selected';}?>>Bauhaus</option>
                              <option value="Blacklight" <?php if($_POST['ddlFontList']=='Blacklight'){ echo 'selected=selected';}?>>Blacklight</option>
                              <option value="Block Caps" <?php if($_POST['ddlFontList']=='Block Caps'){ echo 'selected=selected';}?>>Block Caps</option>
                              <option value="Block1" <?php if($_POST['ddlFontList']=='Block1'){ echo 'selected=selected';}?>>Block1</option>
                              <option value="Block2" <?php if($_POST['ddlFontList']=='Block2'){ echo 'selected=selected';}?>>Block2</option>
                              <option value="Block2-Auto" <?php if($_POST['ddlFontList']=='"Block2-Auto'){ echo 'selected=selected';}?>>Block2-Auto</option>
                              <option value="Bodoni" <?php if($_POST['ddlFontList']=='Bodoni'){ echo 'selected=selected';}?>>Bodoni</option>
                              <option value="Book Script" <?php if($_POST['ddlFontList']=='Book Script'){ echo 'selected=selected';}?>>Book Script</option>
                              <option value="Border Block2" <?php if($_POST['ddlFontList']=='Border Block2'){ echo 'selected=selected';}?>>Border Block2</option>
                              <option value="Borders Alphabet" <?php if($_POST['ddlFontList']=='Borders Alphabet'){ echo 'selected=selected';}?>>Borders Alphabet</option>
                              <option value="Bravo" <?php if($_POST['ddlFontList']=='Bravo'){ echo 'selected=selected';}?>>Bravo</option>
                              <option value="CARLA" <?php if($_POST['ddlFontList']=='CARLA'){ echo 'selected=selected';}?>>CARLA</option>
                              <option value="Castle" <?php if($_POST['ddlFontList']=='Castle'){ echo 'selected=selected';}?>>Castle</option>
                              <option value="Casual Serif" <?php if($_POST['ddlFontList']=='Casual Serif'){ echo 'selected=selected';}?>>Casual Serif</option>
                              <option value="Cayman" <?php if($_POST['ddlFontList']=='Cayman'){ echo 'selected=selected';}?>>Cayman</option>
                              <option value="Centurion" <?php if($_POST['ddlFontList']=='Centurion'){ echo 'selected=selected';}?>>Centurion</option>
                              <option value="Chancery" <?php if($_POST['ddlFontList']=='Chancery'){ echo 'selected=selected';}?>>Chancery</option>
                              <option value="Charcuterie" <?php if($_POST['ddlFontList']=='Charcuterie'){ echo 'selected=selected';}?>>Charcuterie</option>
                              <option value="Cheltenham Tall" <?php if($_POST['ddlFontList']=='Cheltenham Tall'){ echo 'selected=selected';}?>>Cheltenham Tall</option>
                              <option value="Cheshire" <?php if($_POST['ddlFontList']=='Cheshire'){ echo 'selected=selected';}?>>Cheshire</option>
                              <option value="City Medium" <?php if($_POST['ddlFontList']=='City Medium'){ echo 'selected=selected';}?>>City Medium</option>
                              <option value="City Script" <?php if($_POST['ddlFontList']=='City Script'){ echo 'selected=selected';}?>>City Script</option>
                              <option value="Civic" <?php if($_POST['ddlFontList']=='Civic'){ echo 'selected=selected';}?>>Civic</option>
                              <option value="College" <?php if($_POST['ddlFontList']=='College'){ echo 'selected=selected';}?>>College</option>
                              <option value="College Appliqué" <?php if($_POST['ddlFontList']=='College Appliqué'){ echo 'selected=selected';}?>>College Appliqué</option>
                              <option value="Columbo" <?php if($_POST['ddlFontList']=='Columbo'){ echo 'selected=selected';}?>>Columbo</option>
                              <option value="Comics" <?php if($_POST['ddlFontList']=='Comics'){ echo 'selected=selected';}?>>Comics</option>
                              <option value="Copperplate" <?php if($_POST['ddlFontList']=='Copperplate'){ echo 'selected=selected';}?>>Copperplate</option>
                              <option value="Crayfish" <?php if($_POST['ddlFontList']=='Crayfish'){ echo 'selected=selected';}?>>Crayfish</option>
                              <option value="Crest Appliqué" <?php if($_POST['ddlFontList']=='Crest Appliqué'){ echo 'selected=selected';}?>>Crest Appliqué</option>
                              <option value="Crests" <?php if($_POST['ddlFontList']=='Crests'){ echo 'selected=selected';}?>>Crests</option>
                              <option value="Crevasse" <?php if($_POST['ddlFontList']=='Crevasse'){ echo 'selected=selected';}?>>Crevasse</option>
                              <option value="Croissant" <?php if($_POST['ddlFontList']=='Croissant'){ echo 'selected=selected';}?>>Croissant</option>
                              <option value="Curly" <?php if($_POST['ddlFontList']=='Curly'){ echo 'selected=selected';}?>>Curly</option>
                              <option value="Dauphin" <?php if($_POST['ddlFontList']=='Dauphin'){ echo 'selected=selected';}?>>Dauphin</option>
                              <option value="Detex Normal" <?php if($_POST['ddlFontList']=='Detex Normal'){ echo 'selected=selected';}?>>Detex Normal</option>
                              <option value="Dextor" <?php if($_POST['ddlFontList']=='Dextor'){ echo 'selected=selected';}?>>Dextor</option>
                              <option value="Discoteque" <?php if($_POST['ddlFontList']=='Discoteque'){ echo 'selected=selected';}?>>Discoteque</option>
                              <option value="Dotti" <?php if($_POST['ddlFontList']=='Dotti'){ echo 'selected=selected';}?>>Dotti</option>
                              <option value="Dr Zeus" <?php if($_POST['ddlFontList']=='Dr Zeus'){ echo 'selected=selected';}?>>Dr Zeus</option>
                              <option value="Easy Script" <?php if($_POST['ddlFontList']=='Easy Script'){ echo 'selected=selected';}?>>Easy Script</option>
                              <option value="Edwardian Script" <?php if($_POST['ddlFontList']=='Edwardian Script'){ echo 'selected=selected';}?>>Edwardian Script</option>
                              <option value="Enchantment" <?php if($_POST['ddlFontList']=='Enchantment'){ echo 'selected=selected';}?>>Enchantment</option>
                              <option value="Energy" <?php if($_POST['ddlFontList']=='Energy'){ echo 'selected=selected';}?>>Energy</option>
                              <option value="English Village" <?php if($_POST['ddlFontList']=='English Village'){ echo 'selected=selected';}?>>English Village</option>
                              <option value="Enviro" <?php if($_POST['ddlFontList']=='Enviro'){ echo 'selected=selected';}?>>Enviro</option>
                              <option value="Fancy Monogram" <?php if($_POST['ddlFontList']=='Fancy Monogram'){ echo 'selected=selected';}?>>Fancy Monogram</option>
                              <option value="Felt Tip" <?php if($_POST['ddlFontList']=='Felt Tip'){ echo 'selected=selected';}?>>Felt Tip</option>
                              <option value="Flair Script" <?php if($_POST['ddlFontList']=='Flair Script'){ echo 'selected=selected';}?>>Flair Script</option>
                              <option value="Flares" <?php if($_POST['ddlFontList']=='Flares'){ echo 'selected=selected';}?>>Flares</option>
                              <option value="Flash" <?php if($_POST['ddlFontList']=='Flash'){ echo 'selected=selected';}?>>Flash</option>
                              <option value="Flourish Light" <?php if($_POST['ddlFontList']=='Flourish Light'){ echo 'selected=selected';}?>>Flourish Light</option>
                              <option value="Folio Condensed" <?php if($_POST['ddlFontList']=='Folio Condensed'){ echo 'selected=selected';}?>>Folio Condensed</option>
                              <option value="Formal Script" <?php if($_POST['ddlFontList']=='Formal Script'){ echo 'selected=selected';}?>>Formal Script</option>
                              <option value="Free Style" <?php if($_POST['ddlFontList']=='Free Style'){ echo 'selected=selected';}?>>Free Style</option>
                              <option value="Futura" <?php if($_POST['ddlFontList']=='Futura'){ echo 'selected=selected';}?>>Futura</option>
                              <option value="Futura Border 2C" <?php if($_POST['ddlFontList']=='Futura Border 2C'){ echo 'selected=selected';}?>>Futura Border 2C</option>
                              <option value="Futura Outline" <?php if($_POST['ddlFontList']=='Futura Outline'){ echo 'selected=selected';}?>>Futura Outline</option>
                              <option value="GAELIC" <?php if($_POST['ddlFontList']=='GAELIC'){ echo 'selected=selected';}?>>GAELIC</option>
                              <option value="Garamond" <?php if($_POST['ddlFontList']=='Garamond'){ echo 'selected=selected';}?>>Garamond</option>
                              <option value="Glory Appliqué" <?php if($_POST['ddlFontList']=='Glory Appliqué'){ echo 'selected=selected';}?>>Glory Appliqué</option>
                              <option value="Goudy Sans" <?php if($_POST['ddlFontList']=='Goudy Sans'){ echo 'selected=selected';}?>>Goudy Sans</option>
                              <option value="Greek" <?php if($_POST['ddlFontList']=='Greek'){ echo 'selected=selected';}?>>Greek</option>
                              <option value="Greek Script" <?php if($_POST['ddlFontList']=='Greek Script'){ echo 'selected=selected';}?>>Greek Script</option>
                              <option value="Greek Spionic" <?php if($_POST['ddlFontList']=='Greek Spionic'){ echo 'selected=selected';}?>>Greek Spionic</option>
                              <option value="Hana" <?php if($_POST['ddlFontList']=='Hana'){ echo 'selected=selected';}?>>Hana</option>
                              <option value="Handel Gothic" <?php if($_POST['ddlFontList']=='Handel Gothic'){ echo 'selected=selected';}?>>Handel Gothic</option>
                              <option value="Handicraft" <?php if($_POST['ddlFontList']=='Handicraft'){ echo 'selected=selected';}?>>Handicraft</option>
                              <option value="Handy Script" <?php if($_POST['ddlFontList']=='Handy Script'){ echo 'selected=selected';}?>>Handy Script</option>
                              <option value="Hebrew Chaya" <?php if($_POST['ddlFontList']=='Hebrew Chaya'){ echo 'selected=selected';}?>>Hebrew Chaya</option>
                              <option value="Helvetica" <?php if($_POST['ddlFontList']=='Helvetica'){ echo 'selected=selected';}?>>Helvetica</option>
                              <option value="Helvetica Small" <?php if($_POST['ddlFontList']=='Helvetica Small'){ echo 'selected=selected';}?>>Helvetica Small</option>
                              <option value="Hobo" <?php if($_POST['ddlFontList']=='Hobo'){ echo 'selected=selected';}?>>Hobo</option>
                              <option value="Impress" <?php if($_POST['ddlFontList']=='Impress'){ echo 'selected=selected';}?>>Impress</option>
                              <option value="Informal" <?php if($_POST['ddlFontList']=='Informal'){ echo 'selected=selected';}?>>Informal</option>
                              <option value="Italian Script" <?php if($_POST['ddlFontList']=='Italian Script'){ echo 'selected=selected';}?>>Italian Script</option>
                              <option value="Jikharev" <?php if($_POST['ddlFontList']=='Jikharev'){ echo 'selected=selected';}?>>Jikharev</option>
                              <option value="Kabel" <?php if($_POST['ddlFontList']=='Kabel'){ echo 'selected=selected';}?>>Kabel</option>
                              <option value="Karin Script" <?php if($_POST['ddlFontList']=='Karin Script'){ echo 'selected=selected';}?>>Karin Script</option>
                              <option value="Kids" <?php if($_POST['ddlFontList']=='Kids'){ echo 'selected=selected';}?>>Kids</option>
                              <option value="Kindergarten Block" <?php if($_POST['ddlFontList']=='Kindergarten Block'){ echo 'selected=selected';}?>>Kindergarten Block</option>
                              <option value="Krone" <?php if($_POST['ddlFontList']=='Krone'){ echo 'selected=selected';}?>>Krone</option>
                              <option value="Lariat" <?php if($_POST['ddlFontList']=='Lariat'){ echo 'selected=selected';}?>>Lariat</option>
                              <option value="Lazer" <?php if($_POST['ddlFontList']=='Lazer'){ echo 'selected=selected';}?>>Lazer</option>
                              <option value="Legal Block" <?php if($_POST['ddlFontList']=='Legal Block'){ echo 'selected=selected';}?>>Legal Block</option>
                              <option value="Locker" <?php if($_POST['ddlFontList']=='Locker'){ echo 'selected=selected';}?>>Locker</option>
                              <option value="Lublik" <?php if($_POST['ddlFontList']=='Lublik'){ echo 'selected=selected';}?>>Lublik</option>
                              <option value="Lydian" <?php if($_POST['ddlFontList']=='Lydian'){ echo 'selected=selected';}?>>Lydian</option>
                              <option value="Mandarin" <?php if($_POST['ddlFontList']=='Mandarin'){ echo 'selected=selected';}?>>Mandarin</option>
                              <option value="Market" <?php if($_POST['ddlFontList']=='Market'){ echo 'selected=selected';}?>>Market</option>
                              <option value="Matisse" <?php if($_POST['ddlFontList']=='Matisse'){ echo 'selected=selected';}?>>Matisse</option>
                              <option value="Matrix" <?php if($_POST['ddlFontList']=='Matrix'){ echo 'selected=selected';}?>>Matrix</option>
                              <option value="Meister Block" <?php if($_POST['ddlFontList']=='Meister Block'){ echo 'selected=selected';}?>>Meister Block</option>
                              <option value="Memo Script" <?php if($_POST['ddlFontList']=='Memo Script'){ echo 'selected=selected';}?>>Memo Script</option>
                              <option value="Micro Block" <?php if($_POST['ddlFontList']=='Micro Block'){ echo 'selected=selected';}?>>Micro Block</option>
                              <option value="Microgramma" <?php if($_POST['ddlFontList']=='Microgramma'){ echo 'selected=selected';}?>>Microgramma</option>
                              <option value="Microscan" <?php if($_POST['ddlFontList']=='Microscan'){ echo 'selected=selected';}?>>Microscan</option>
                              <option value="Miniature Block" <?php if($_POST['ddlFontList']=='Miniature Block'){ echo 'selected=selected';}?>>Miniature Block</option>
                              <option value="Moly" <?php if($_POST['ddlFontList']=='Moly'){ echo 'selected=selected';}?>>Moly</option>
                              <option value="Monoglyceride" <?php if($_POST['ddlFontList']=='Monoglyceride'){ echo 'selected=selected';}?>>Monoglyceride</option>
                              <option value="Monoglyceride Bold" <?php if($_POST['ddlFontList']=='Monoglyceride Bold'){ echo 'selected=selected';}?>>Monoglyceride Bold</option>
                              <option value="Museo" <?php if($_POST['ddlFontList']=='Museo'){ echo 'selected=selected';}?>>Museo</option>
                              <option value="Narrow Block" <?php if($_POST['ddlFontList']=='Narrow Block'){ echo 'selected=selected';}?>>Narrow Block</option>
                              <option value="News Outline" <?php if($_POST['ddlFontList']=='News Outline'){ echo 'selected=selected';}?>>News Outline</option>
                              <option value="Octagon Monogram" <?php if($_POST['ddlFontList']=='Octagon Monogram'){ echo 'selected=selected';}?>>Octagon Monogram</option>
                              <option value="Old English" <?php if($_POST['ddlFontList']=='Old English'){ echo 'selected=selected';}?>>Old English</option>
                              <option value="Olivia" <?php if($_POST['ddlFontList']=='Olivia'){ echo 'selected=selected';}?>>Olivia</option>
                              <option value="Orient Express" <?php if($_POST['ddlFontList']=='Orient Express'){ echo 'selected=selected';}?>>Orient Express</option>
                              <option value="Outline Block" <?php if($_POST['ddlFontList']=='Outline Block'){ echo 'selected=selected';}?>>Outline Block</option>
                              <option value="Pacific North West" <?php if($_POST['ddlFontList']=='Pacific North West'){ echo 'selected=selected';}?>>Pacific North West</option>
                              <option value="Pixie" <?php if($_POST['ddlFontList']=='Pixie'){ echo 'selected=selected';}?>>Pixie</option>
                              <option value="Poetic Script" <?php if($_POST['ddlFontList']=='Poetic Script'){ echo 'selected=selected';}?>>Poetic Script</option>
                              <option value="POINT MONOGRAM" <?php if($_POST['ddlFontList']=='POINT MONOGRAM'){ echo 'selected=selected';}?>>POINT MONOGRAM</option>
                              <option value="Pomander" <?php if($_POST['ddlFontList']=='Pomander'){ echo 'selected=selected';}?>>Pomander</option>
                              <option value="Racer" <?php if($_POST['ddlFontList']=='Racer'){ echo 'selected=selected';}?>>Racer</option>
                              <option value="Round Block" <?php if($_POST['ddlFontList']=='Round Block'){ echo 'selected=selected';}?>>Round Block</option>
                              <option value="Royale" <?php if($_POST['ddlFontList']=='Royale'){ echo 'selected=selected';}?>>Royale</option>
                              <option value="Run Block" <?php if($_POST['ddlFontList']=='Run Block'){ echo 'selected=selected';}?>>Run Block</option>
                              <option value="Run Cardigan" <?php if($_POST['ddlFontList']=='Run Cardigan'){ echo 'selected=selected';}?>>Run Cardigan</option>
                              <option value="Run Freehand" <?php if($_POST['ddlFontList']=='Run Freehand'){ echo 'selected=selected';}?>>Run Freehand</option>
                              <option value="Run Liberty" <?php if($_POST['ddlFontList']=='Run Liberty'){ echo 'selected=selected';}?>>Run Liberty</option>
                              <option value="Run Murray Hill" <?php if($_POST['ddlFontList']=='Run Murray Hill'){ echo 'selected=selected';}?>>Run Murray Hill</option>
                              <option value="Run Script" <?php if($_POST['ddlFontList']=='Run Script'){ echo 'selected=selected';}?>>Run Script</option>
                              <option value="Russian Textbook" <?php if($_POST['ddlFontList']=='Russian Textbook'){ echo 'selected=selected';}?>>Russian Textbook</option>
                              <option value="Schoolbook" <?php if($_POST['ddlFontList']=='Schoolbook'){ echo 'selected=selected';}?>>Schoolbook</option>
                              <option value="Script1" <?php if($_POST['ddlFontList']=='Script1'){ echo 'selected=selected';}?>>Script1</option>
                              <option value="Script2" <?php if($_POST['ddlFontList']=='Script2'){ echo 'selected=selected';}?>>Script2</option>
                              <option value="Script3" <?php if($_POST['ddlFontList']=='Script3'){ echo 'selected=selected';}?>>Script3</option>
                              <option value="Script4" <?php if($_POST['ddlFontList']=='Script4'){ echo 'selected=selected';}?>>Script4</option>
                              <option value="Script5" <?php if($_POST['ddlFontList']=='Script5'){ echo 'selected=selected';}?>>Script5</option>
                              <option value="Script6" <?php if($_POST['ddlFontList']=='Script6'){ echo 'selected=selected';}?>>Script6</option>
                              <option value="Script7" <?php if($_POST['ddlFontList']=='Script7'){ echo 'selected=selected';}?>>Script7</option>
                              <option value="Script8" <?php if($_POST['ddlFontList']=='Script8'){ echo 'selected=selected';}?>>Script8</option>
                              <option value="Seagull" <?php if($_POST['ddlFontList']=='Seagull'){ echo 'selected=selected';}?>>Seagull</option>
                              <option value="Seal Monogram" <?php if($_POST['ddlFontList']=='Seal Monogram'){ echo 'selected=selected';}?>>Seal Monogram</option>
                              <option value="Serif1" <?php if($_POST['ddlFontList']=='Serif1'){ echo 'selected=selected';}?>>Serif1</option>
                              <option value="Serif2" <?php if($_POST['ddlFontList']=='Serif2'){ echo 'selected=selected';}?>>Serif2</option>
                              <option value="Serif3" <?php if($_POST['ddlFontList']=='Serif3'){ echo 'selected=selected';}?>>Serif3</option>
                              <option value="Shadow Street" <?php if($_POST['ddlFontList']=='Shadow Street'){ echo 'selected=selected';}?>>Shadow Street</option>
                              <option value="Slim Block" <?php if($_POST['ddlFontList']=='Slim Block'){ echo 'selected=selected';}?>>Slim Block</option>
                              <option value="Sm Cooper" <?php if($_POST['ddlFontList']=='Sm Cooper'){ echo 'selected=selected';}?>>Sm Cooper</option>
                              <option value="Sm HighTower" <?php if($_POST['ddlFontList']=='Sm HighTower'){ echo 'selected=selected';}?>>Sm HighTower</option>
                              <option value="Sm Script" <?php if($_POST['ddlFontList']=='Sm Script'){ echo 'selected=selected';}?>>Sm Script</option>
                              <option value="Small Block1" <?php if($_POST['ddlFontList']=='Small Block1'){ echo 'selected=selected';}?>>Small Block1</option>
                              <option value="Small Block2" <?php if($_POST['ddlFontList']=='Small Block2'){ echo 'selected=selected';}?>>Small Block2</option>
                              <option value="Small Serif 1" <?php if($_POST['ddlFontList']=='Small Serif 1'){ echo 'selected=selected';}?>>Small Serif 1</option>
                              <option value="Sofachrome" <?php if($_POST['ddlFontList']=='Sofachrome'){ echo 'selected=selected';}?>>Sofachrome</option>
                              <option value="Souvenir" <?php if($_POST['ddlFontList']=='Souvenir'){ echo 'selected=selected';}?>>Souvenir</option>
                              <option value="Speedy" <?php if($_POST['ddlFontList']=='Speedy'){ echo 'selected=selected';}?>>Speedy</option>
                              <option value="Sports" <?php if($_POST['ddlFontList']=='Sports'){ echo 'selected=selected';}?>>Sports</option>
                              <option value="Square Block" <?php if($_POST['ddlFontList']=='Square Block'){ echo 'selected=selected';}?>>Square Block</option>
                              <option value="Staccato" <?php if($_POST['ddlFontList']=='Staccato'){ echo 'selected=selected';}?>>Staccato</option>
                              <option value="Stencil Block" <?php if($_POST['ddlFontList']=='Stencil Block'){ echo 'selected=selected';}?>>Stencil Block</option>
                              <option value="Super Block" <?php if($_POST['ddlFontList']=='Super Block'){ echo 'selected=selected';}?>>Super Block</option>
                              <option value="Swiss" <?php if($_POST['ddlFontList']=='Swiss'){ echo 'selected=selected';}?>>Swiss</option>
                              <option value="Swiss Run Hollow" <?php if($_POST['ddlFontList']=='Swiss Run Hollow'){ echo 'selected=selected';}?>>Swiss Run Hollow</option>
                              <option value="Swiss Run Satin" <?php if($_POST['ddlFontList']=='Swiss Run Satin'){ echo 'selected=selected';}?>>Swiss Run Satin</option>
                              <option value="Tahoma" <?php if($_POST['ddlFontList']=='Tahoma'){ echo 'selected=selected';}?>>Tahoma</option>
                              <option value="Text Block" <?php if($_POST['ddlFontList']=='Text Block'){ echo 'selected=selected';}?>>Text Block</option>
                              <option value="Thriller" <?php if($_POST['ddlFontList']=='Thriller'){ echo 'selected=selected';}?>>Thriller</option>
                              <option value="Times Roman" <?php if($_POST['ddlFontList']=='Times Roman'){ echo 'selected=selected';}?>>Times Roman</option>
                              <option value="Times Small" <?php if($_POST['ddlFontList']=='Times Small'){ echo 'selected=selected';}?>>Times Small</option>
                              <option value="Toon" <?php if($_POST['ddlFontList']=='Toon'){ echo 'selected=selected';}?>>Toon</option>
                              <option value="Turncoat" <?php if($_POST['ddlFontList']=='Turncoat'){ echo 'selected=selected';}?>>Turncoat</option>
                              <option value="Tusj" <?php if($_POST['ddlFontList']=='Tusj'){ echo 'selected=selected';}?>>Tusj</option>
                              <option value="Typewriter" <?php if($_POST['ddlFontList']=='Typewriter'){ echo 'selected=selected';}?>>Typewriter</option>
                              <option value="Upright Script" <?php if($_POST['ddlFontList']=='Upright Script'){ echo 'selected=selected';}?>>Upright Script</option>
                              <option value="Urbane" <?php if($_POST['ddlFontList']=='Urbane'){ echo 'selected=selected';}?>>Urbane</option>
                              <option value="Utility Block" <?php if($_POST['ddlFontList']=='Utility Block'){ echo 'selected=selected';}?>>Utility Block</option>
                              <option value="Veranda" <?php if($_POST['ddlFontList']=='Veranda'){ echo 'selected=selected';}?>>Veranda</option>
                              <option value="Victorian" <?php if($_POST['ddlFontList']=='Victorian'){ echo 'selected=selected';}?>>Victorian</option>
                              <option value="Viking" <?php if($_POST['ddlFontList']=='Viking'){ echo 'selected=selected';}?>>Viking</option>
                              <option value="Western" <?php if($_POST['ddlFontList']=='Western'){ echo 'selected=selected';}?>>Western</option>
                              <option value="Western Serif" <?php if($_POST['ddlFontList']=='Western Serif'){ echo 'selected=selected';}?>>Western Serif</option>
                              <option value="Westminster" <?php if($_POST['ddlFontList']=='Westminster'){ echo 'selected=selected';}?>>Westminster</option>
                              <option value="Woodstock" <?php if($_POST['ddlFontList']=='Woodstock'){ echo 'selected=selected';}?>>Woodstock</option>
                              <option value="(JP) Heisei Gosic" <?php if($_POST['ddlFontList']=='(JP) Heisei Gosic'){ echo 'selected=selected';}?>>(JP) Heisei Gosic</option>
                              <option value="(JP) Heisei Gyosho" <?php if($_POST['ddlFontList']=='(JP) Heisei Gyosho'){ echo 'selected=selected';}?>>(JP) Heisei Gyosho</option>
                              <option value="(JP) Heisei Kaisho" <?php if($_POST['ddlFontList']=='(JP) Heisei Kaisho'){ echo 'selected=selected';}?>>(JP) Heisei Kaisho</option>
                              <option value="(JP) Heisei Kantei" <?php if($_POST['ddlFontList']=='(JP) Heisei Kantei'){ echo 'selected=selected';}?>>(JP) Heisei Kantei</option>
                              <option value="(JP) Heisei Maru Gosic" <?php if($_POST['ddlFontList']=='(JP) Heisei Maru Gosic'){ echo 'selected=selected';}?>>(JP) Heisei Maru Gosic</option>
                              <option value="(JP) Heisei Mincho" <?php if($_POST['ddlFontList']=='(JP) Heisei Mincho'){ echo 'selected=selected';}?>>(JP) Heisei Mincho</option>
                              <option value="01.EMBIS 궁서체" <?php if($_POST['ddlFontList']=='01.EMBIS 궁서체'){ echo 'selected=selected';}?>>01.EMBIS 궁서체</option>
                              <option value="02 EMBIS 명조체" <?php if($_POST['ddlFontList']=='02 EMBIS 명조체'){ echo 'selected=selected';}?>>02 EMBIS 명조체</option>
                              <option value="5mm Typewriter PPC" <?php if($_POST['ddlFontList']=='5mm Typewriter PPC'){ echo 'selected=selected';}?>>5mm Typewriter PPC</option>
                              <option value="ALT SHIRT BLOCK BK 6MM" <?php if($_POST['ddlFontList']=='ALT SHIRT BLOCK BK 6MM'){ echo 'selected=selected';}?>>ALT SHIRT BLOCK BK 6MM</option>
                              <option value="ALT SHIRT SCRIPT SC 6MM" <?php if($_POST['ddlFontList']=='ALT SHIRT SCRIPT SC 6MM'){ echo 'selected=selected';}?>>ALT SHIRT SCRIPT SC 6MM</option>
                              <option value="Amerigo Md BT Medium" <?php if($_POST['ddlFontList']=='Amerigo Md BT Medium'){ echo 'selected=selected';}?>>Amerigo Md BT Medium</option>
                              <option value="Arial Bold SS" <?php if($_POST['ddlFontList']=='Arial Bold SS'){ echo 'selected=selected';}?>>Arial Bold SS</option>
                              <option value="art deco mgm" <?php if($_POST['ddlFontList']=='art deco mgm'){ echo 'selected=selected';}?>>art deco mgm</option>
                              <option value="bamboo twisty" <?php if($_POST['ddlFontList']=='bamboo twisty'){ echo 'selected=selected';}?>>bamboo twisty</option>
                              <option value="baroque lines" <?php if($_POST['ddlFontList']=='baroque lines'){ echo 'selected=selected';}?>>baroque lines</option>
                              <option value="baroque mgm" <?php if($_POST['ddlFontList']=='baroque mgm'){ echo 'selected=selected';}?>>baroque mgm</option>
                              <option value="BBR30 7MM" <?php if($_POST['ddlFontList']=='BBR30 7MM'){ echo 'selected=selected';}?>>BBR30 7MM</option>
                              <option value="BBR32 7MM" <?php if($_POST['ddlFontList']=='BBR32 7MM'){ echo 'selected=selected';}?>>BBR32 7MM</option>
                              <option value="BBR46 5MM" <?php if($_POST['ddlFontList']=='BBR46 5MM'){ echo 'selected=selected';}?>>BBR46 5MM</option>
                              <option value="BBR70 7MM" <?php if($_POST['ddlFontList']=='BBR70 7MM'){ echo 'selected=selected';}?>>BBR70 7MM</option>
                              <option value="caeldera" <?php if($_POST['ddlFontList']=='caeldera'){ echo 'selected=selected';}?>>caeldera</option>
                              <option value="circlemgm" <?php if($_POST['ddlFontList']=='cornerstone'){ echo 'selected=selected';}?>>circlemgm</option>
                              <option value="cornerstone" <?php if($_POST['ddlFontList']=='cornerstone'){ echo 'selected=selected';}?>>cornerstone</option>
                              <option value="daimler" <?php if($_POST['ddlFontList']=='daimler'){ echo 'selected=selected';}?>>daimler</option>
                              <option value="dr soos" <?php if($_POST['ddlFontList']=='dr soos'){ echo 'selected=selected';}?>>dr soos</option>
                              <option value="engraver" <?php if($_POST['ddlFontList']=='engraver'){ echo 'selected=selected';}?>>engraver</option>
                              <option value="fishtails" <?php if($_POST['ddlFontList']=='fishtails'){ echo 'selected=selected';}?>>fishtails</option>
                              <option value="freight sans" <?php if($_POST['ddlFontList']=='freight sans'){ echo 'selected=selected';}?>>freight sans</option>
                              <option value="gilly" <?php if($_POST['ddlFontList']=='gilly'){ echo 'selected=selected';}?>>gilly</option>
                              <option value="Guard 10mm" <?php if($_POST['ddlFontList']=='Guard 10mm'){ echo 'selected=selected';}?>>Guard 10mm</option>
                              <option value="harrington" <?php if($_POST['ddlFontList']=='harrington'){ echo 'selected=selected';}?>>harrington</option>
                              <option value="harrypotter" <?php if($_POST['ddlFontList']=='harrypotter'){ echo 'selected=selected';}?>>harrypotter</option>
                              <option value="impact" <?php if($_POST['ddlFontList']=='impact'){ echo 'selected=selected';}?>>impact</option>
                              <option value="JHI BBR40 PAU DIL BL 7MM" <?php if($_POST['ddlFontList']=='JHI BBR40 PAU DIL BL 7MM'){ echo 'selected=selected';}?>>JHI BBR40 PAU DIL BL 7MM</option>
                              <option value="JHI BBR75 PAU DIL SC 7MM" <?php if($_POST['ddlFontList']=='JHI BBR75 PAU DIL SC 7MM'){ echo 'selected=selected';}?>>JHI BBR75 PAU DIL SC 7MM</option>
                              <option value="JHI KNIT PANT BLOCK BK 5MM" <?php if($_POST['ddlFontList']=='JHI KNIT PANT BLOCK BK 5MM'){ echo 'selected=selected';}?>>JHI KNIT PANT BLOCK BK 5MM</option>
                              <option value="JHI KNIT PANT BLOCK BK 7MM" <?php if($_POST['ddlFontList']=='JHI KNIT PANT BLOCK BK 7MM'){ echo 'selected=selected';}?>>JHI KNIT PANT BLOCK BK 7MM</option>
                              <option value="JHI PANT BLOCK BM 5MM" <?php if($_POST['ddlFontList']=='JHI PANT BLOCK BM 5MM'){ echo 'selected=selected';}?>>JHI PANT BLOCK BM 5MM</option>
                              <option value="JHIBK5MM" <?php if($_POST['ddlFontList']=='JHIBK5MM'){ echo 'selected=selected';}?>>JHIBK5MM</option>
                              <option value="JHIBK7MM" <?php if($_POST['ddlFontList']=='JHIBK7MM'){ echo 'selected=selected';}?>>JHIBK7MM</option>
                              <option value="Lego Regular" <?php if($_POST['ddlFontList']=='Lego Regular'){ echo 'selected=selected';}?>>Lego Regular</option>
                              <option value="lines" <?php if($_POST['ddlFontList']=='lines'){ echo 'selected=selected';}?>>lines</option>
                              <option value="meta" <?php if($_POST['ddlFontList']=='meta'){ echo 'selected=selected';}?>>meta</option>
                              <option value="mgm arabesque" <?php if($_POST['ddlFontList']=='mgm arabesque'){ echo 'selected=selected';}?>>mgm arabesque</option>
                              <option value="mgm baroque" <?php if($_POST['ddlFontList']=='mgm baroque'){ echo 'selected=selected';}?>>mgm baroque</option>
                              <option value="modern fancy" <?php if($_POST['ddlFontList']=='modern fancy'){ echo 'selected=selected';}?>>modern fancy</option>
                              <option value="neuzeit plymoth bold" <?php if($_POST['ddlFontList']=='neuzeit plymoth bold'){ echo 'selected=selected';}?>>neuzeit plymoth bold</option>
                              <option value="niagra" <?php if($_POST['ddlFontList']=='niagra'){ echo 'selected=selected';}?>>niagra</option>
                              <option value="norwester" <?php if($_POST['ddlFontList']=='norwester'){ echo 'selected=selected';}?>>norwester</option>
                              <option value="oklahoma" <?php if($_POST['ddlFontList']=='oklahoma'){ echo 'selected=selected';}?>>oklahoma</option>
                              <option value="Oul PPC Diamond 12mm" <?php if($_POST['ddlFontList']=='Oul PPC Diamond 12mm'){ echo 'selected=selected';}?>>Oul PPC Diamond 12mm</option>
                              <option value="Oul PPC Script 6mm" <?php if($_POST['ddlFontList']=='Oul PPC Script 6mm'){ echo 'selected=selected';}?>>Oul PPC Script 6mm</option>
                              <option value="Palatino Linotype Regular" <?php if($_POST['ddlFontList']=='Palatino Linotype Regular'){ echo 'selected=selected';}?>>Palatino Linotype Regular</option>
                              <option value="PPC SHIRT ARIAL BOLD AB 5MM" <?php if($_POST['ddlFontList']=='PPC SHIRT ARIAL BOLD AB 5MM'){ echo 'selected=selected';}?>>PPC SHIRT ARIAL BOLD AB 5MM</option>
                              <option value="PPC SHIRT CUSTOM SCRIPT CS 6MM" <?php if($_POST['ddlFontList']=='PPC SHIRT CUSTOM SCRIPT CS 6MM'){ echo 'selected=selected';}?>>PPC SHIRT CUSTOM SCRIPT CS 6MM</option>
                              <option value="PPC SHIRT DIAMOND 12MM" <?php if($_POST['ddlFontList']=='PPC SHIRT DIAMOND 12MM'){ echo 'selected=selected';}?>>PPC SHIRT DIAMOND 12MM</option>
                              <option value="PPC SHIRT REGENCY SCRIP 5MM" <?php if($_POST['ddlFontList']=='PPC SHIRT REGENCY SCRIP 5MM'){ echo 'selected=selected';}?>>PPC SHIRT REGENCY SCRIP 5MM</option>
                              <option value="PPC SHIRT TYPEWRITER TW 5MM" <?php if($_POST['ddlFontList']=='PPC SHIRT TYPEWRITER TW 5MM'){ echo 'selected=selected';}?>>PPC SHIRT TYPEWRITER TW 5MM</option>
                              <option value="PPC Typewriter 5MM" <?php if($_POST['ddlFontList']=='PPC Typewriter 5MM'){ echo 'selected=selected';}?>>PPC Typewriter 5MM</option>
                              <option value="PPCAB 5MM" <?php if($_POST['ddlFontList']=='PPCAB 5MM'){ echo 'selected=selected';}?>>PPCAB 5MM</option>
                              <option value="PPCRS 5MM" <?php if($_POST['ddlFontList']=='PPCRS 5MM'){ echo 'selected=selected';}?>>PPCRS 5MM</option>
                              <option value="PPCTW 5MM" <?php if($_POST['ddlFontList']=='PPCTW 5MM'){ echo 'selected=selected';}?>>PPCTW 5MM</option>
                              <option value="quadon bold" <?php if($_POST['ddlFontList']=='quadon bold'){ echo 'selected=selected';}?>>quadon bold</option>
                              <option value="SAV SHIRT STRAIGHT ST" <?php if($_POST['ddlFontList']=='SAV SHIRT STRAIGHT ST'){ echo 'selected=selected';}?>>SAV SHIRT STRAIGHT ST</option>
                              <option value="SAV SHIRT SWOOSH SW" <?php if($_POST['ddlFontList']=='SAV SHIRT SWOOSH SW'){ echo 'selected=selected';}?>>SAV SHIRT SWOOSH SW</option>
                              <option value="SimSun Regular" <?php if($_POST['ddlFontList']=='SimSun Regular'){ echo 'selected=selected';}?>>SimSun Regular</option>
                              <option value="STXingkai Regular" <?php if($_POST['ddlFontList']=='STXingkai Regular'){ echo 'selected=selected';}?>>STXingkai Regular</option>
                              <option value="trade gothic" <?php if($_POST['ddlFontList']=='trade gothic'){ echo 'selected=selected';}?>>trade gothic</option>
                              <option value="trajan bold" <?php if($_POST['ddlFontList']=='trajan bold'){ echo 'selected=selected';}?>>trajan bold</option>
                              <option value="trajan pro" <?php if($_POST['ddlFontList']=='trajan pro'){ echo 'selected=selected';}?>>trajan pro</option>
                              <option value="tungsten bold" <?php if($_POST['ddlFontList']=='tungsten bold'){ echo 'selected=selected';}?>>tungsten bold</option>
                              <option value="Waltograph Medium" <?php if($_POST['ddlFontList']=='Waltograph Medium'){ echo 'selected=selected';}?>>Waltograph Medium</option>
                           </select>
                        </div>
                        <div class="ewa-validate validatorcolumn">
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                           Color
                        </div>
                        <div class="ewa-field valuecolumn">
                           <select name="ddlColorList" id="ddlColorList" >
                              <option  value="0" <?php if($_POST['ddlColorList']=='0'){ echo 'selected=selected';}?>>Black</option>
                              <option value="255" <?php if($_POST['ddlColorList']=='255'){ echo 'selected=selected';}?>>Red</option>
                              <option value="16711680" <?php if($_POST['ddlColorList']=='16711680'){ echo 'selected=selected';}?>>Blue</option>
                              <option value="32768" <?php if($_POST['ddlColorList']=='32768'){ echo 'selected=selected';}?>>Green</option>
                              <option value="55295" <?php if($_POST['ddlColorList']=='55295'){ echo 'selected=selected';}?>>Gold</option>
                           </select>
                        </div>
                        <div class="ewa-validate validatorcolumn">
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                           Height (mm)
                        </div>
                        <div class="ewa-field valuecolumn">
                           <input name="heights" type="text" value="<?php if($_POST['heights']!=''){ echo $_POST['heights'];}else{ echo '10';}?>" id="heights" required onkeypress="return ValidatePhoneNo()" maxlength="5" />
                        </div>
                        <div class="ewa-validate validatorcolumn">
                           <span id="tbHeightRequired" style="color:Red;display:none;">Height can't be empty.</span>
                           <span id="tbHeightRange" style="color:Red;"><?php echo  $error;?></span>
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                           Trueview DPI
                        </div>
                        <div class="ewa-field valuecolumn">
                           <select name="dpTrueviewDPI" id="dpTrueviewDPI">
                              <option value="72" <?php if($_POST['dpTrueviewDPI']=='72'){ echo 'selected=selected';}?>>72</option>
                              <option value="96"  <?php if($_POST['dpTrueviewDPI']=='96'){ echo 'selected=selected';}?>>96</option>
                              <option value="128"  <?php if($_POST['dpTrueviewDPI']=='128'){ echo 'selected=selected';}?>>128</option>
                              <option value="150"  <?php if($_POST['dpTrueviewDPI']=='150'){ echo 'selected=selected';}?>>150</option>
                              <option value="192"  <?php if($_POST['dpTrueviewDPI']=='192'){ echo 'selected=selected';}?>>192</option>
                           </select>
                        </div>
                        <div class="ewa-validate validatorcolumn">
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                           Text
                        </div>
                        <div class="ewa-field valuecolumn">
                           <textarea name="contents" rows="3" cols="20" id="contents"  required><?php if($_POST['contents']!=''){ echo $_POST['contents']; }else { echo 'Lettering'; }?></textarea>
                        </div>
                        <div class="ewa-validate validatorcolumn">
                           <span id="tbTextRequired" style="color:Red;display:none;">Text can't be empty.</span>
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                        </div>
                        <div class="ewa-field valuecolumn">
                           <input id="recipe" type="checkbox" value='1' name="recipe" <?php if($recipe=='1'){ echo 'checked';}?> /><label for="cbShowRecipe">Show Recipe</label>
                        </div>
                        <div class="ewa-validate validatorcolumn">
                        </div>
                     </div>
                     <div class="ewa-field-container">
                        <div class="ewa-field-label">
                        </div>
                        <div class="ewa-field valuecolumn">
                           <input type="submit" name="btnSubmit" value="Create Lettering"  id="btnSubmit" />
                        </div>
                        <div class="ewa-validate validatorcolumn">
                           <span id="lbError" style="color:Red;"></span>
                        </div>
                     </div>
                     <div class="ewa-toolset-container-slider" onclick="sliderOpen();">
                     </div>
                  </div>
                  <div class="ewa-result-container">
                     <h3>Output result:</h3>
                     <!-- DISPLAY RESULTS HERE -->
                     <div class="rightcls">
                        <?php if($filecontents!=''){ ?> <img src="data:image/png;base64,<?php echo  $filecontents;?>"  id="imgResult" style="<?php echo 'height:'.$height.';width:'.$width;?>"/> <?php } ?>
                        <?php if($recipe=='1') { ?> 
                        <textarea name="tbRecipe" rows="13" cols="20" readonly="readonly" id="tbRecipe"><?php echo $recipe_post;?></textarea><?php } ?>
                     </div>
                  </div>
               </div>
            </div>
            <script type="text/javascript">
               //<![CDATA[
               var Page_Validators =  new Array(document.getElementById("tbHeightRequired"), document.getElementById("tbHeightRange"), document.getElementById("tbTextRequired"));
               //]]>
            </script>
            <script type="text/javascript">
               //<![CDATA[
               var tbHeightRequired = document.all ? document.all["tbHeightRequired"] : document.getElementById("tbHeightRequired");
               tbHeightRequired.controltovalidate = "tbHeight";
               tbHeightRequired.errormessage = "Height can\'t be empty.";
               tbHeightRequired.display = "Dynamic";
               tbHeightRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
               tbHeightRequired.initialvalue = "";
               var tbHeightRange = document.all ? document.all["tbHeightRange"] : document.getElementById("tbHeightRange");
               tbHeightRange.controltovalidate = "tbHeight";
               tbHeightRange.errormessage = "Please enter the number between 5 to 50";
               tbHeightRange.display = "Dynamic";
               tbHeightRange.type = "Double";
               tbHeightRange.decimalchar = ".";
               tbHeightRange.evaluationfunction = "RangeValidatorEvaluateIsValid";
               tbHeightRange.maximumvalue = "50.0";
               tbHeightRange.minimumvalue = "5.0";
               var tbTextRequired = document.all ? document.all["tbTextRequired"] : document.getElementById("tbTextRequired");
               tbTextRequired.controltovalidate = "tbText";
               tbTextRequired.errormessage = "Text can\'t be empty.";
               tbTextRequired.display = "Dynamic";
               tbTextRequired.evaluationfunction = "RequiredFieldValidatorEvaluateIsValid";
               tbTextRequired.initialvalue = "";
               //]]>
            </script>
            <script type="text/javascript">
               //<![CDATA[
               
               var Page_ValidationActive = false;
               if (typeof(ValidatorOnLoad) == "function") {
               	ValidatorOnLoad();
               }
               
               function ValidatorOnSubmit() {
               	if (Page_ValidationActive) {
               		return ValidatorCommonOnSubmit();
               	}
               	else {
               		return true;
               	}
               }
               		//]]>
            </script>
         </form>
         <script>
            function sliderOpen() {
            	$('#ewa-toolset-container').toggleClass('open');
            }
            
         </script>
         <script>
            function ValidatePhoneNo() {
            	if ((event.keyCode > 47 && event.keyCode < 58) || event.keyCode == 43 || event.keyCode == 32)
            		return event.returnValue;
            		return event.returnValue = '';
            }
         </script> 
      </div>
   </body>
</html>

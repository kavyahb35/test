<?php

JLoader::registerNamespace('Curl', JPATH_LIBRARIES
    . '/curl/src');

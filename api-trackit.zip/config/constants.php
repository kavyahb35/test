<?php
	
		return [	
			'Api_Url' => 'http://192.168.0.108/04laravel/trackit-api/',
			'Admin_Email'=> 'itadmin@cueserve.com',
			'Form_Email'=> 'hr@cueserve.com',
			'Huff_Api_Url'=>'https://api.hubstaff.com/v1/'
		];
	

	
   

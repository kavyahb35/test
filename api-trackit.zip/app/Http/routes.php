<?php


/* user route */
Route::post('v1/user/authenticate', 'UsersController@authenticate');
Route::post('v1/users', 'UsersController@usersCreate');
Route::get('v1/users', 'UsersController@getUsers');
Route::get('v1/users/{id}', 'UsersController@getUsersDetail');
Route::post('v1/users/{id}', 'UsersController@editUser');
Route::delete('v1/users/{id}', 'UsersController@deleteUser');

Route::post('v1/users/forgotpassword', 'UsersController@forgotPassword1');
Route::post('v1/users/reset-password/{id}', 'UsersController@resetPassword');

/* Log route */
Route::get('v1/users/history-log/{id}', 'UsersController@historyLog');
Route::get('v1/users/history-log', 'UsersController@historyLogAllusers');

/* Task route */
Route::post('v1/users/manual-timer/{id}', 'UsersController@taskReason');
Route::post('v1/users/list-timer/{id}', 'UsersController@taskList');
Route::delete('v1/users/manual-timer/{id}', 'UsersController@deleteTime');
Route::get('v1/users/list-timer-date/{id}/{dat}', 'UsersController@taskListDate');

/* Project route */
Route::post('v1/project/create-project', 'ProjectController@index');
Route::get('v1/hubstaff/getAllOrganizationDetails', 'ProjectController@getAllOrganizationDetails');
Route::post('v1/hubstaff/hubstaff-login', 'ProjectController@hubstaffLogin');

Route::get('v1/hubstaff/getProjectList', 'ProjectController@getProjectList');
Route::post('v1/hubstaff/getProjectTaskList', 'ProjectController@getProjectTaskList');

Route::post('v1/hubstaff/getTaskTime', 'ProjectController@getTaskTime');
Route::post('v1/hubstaff/getTaskList', 'ProjectController@getTaskList');
Route::post('v1/hubstaff/getTask', 'ProjectController@getTask');




























/*
Route::post('v1/users/change-password','UsersController@changePassword');
Route::post('v1/users/change-password1','UsersController@changePassword1');

*/
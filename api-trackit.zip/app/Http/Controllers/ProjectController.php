<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

/* hubstaff package include */
include ('vendor-master/autoload.php');   
use Hubstaff\Hubstaff;   
use Hubstaff\Authentication;   
use Curl\Curl;
   
class ProjectController extends Controller {
	
	/* Add Project API Call */
    public function index(Request $request)
	{
        $tag = new Appmodel();
        echo $Title = $request->input('Title');
    }
	/* Hubstaff login API Call */
	public function hubstaffLogin(Request $request) 
	{
		$Token = $_POST['App_Token'];
		$Email = $_POST['Email'];
		$Password = $_POST['Password'];
		
		$Huff_Api_Url = config('constants.Huff_Api_Url');
		$this->url = $Huff_Api_Url.'auth';
		$curl = new Curl();
		$curl->setHeader('App-Token', $Token);
		$curl->post($this->url, array(
			'email' => $Email,
			'password' => $Password,
		));
		
		if ($curl->error) {			
			if($curl->error_code == '429'){
				echo $res = 'You can`t make any more requests ';
			}else {echo $res = 'Unauthenticated user'; }die;
			
		}
		else {
			$response = json_decode($curl->response);
		}

		$curl->close();
		$res= $response->user; 
		
		$response = json_decode(json_encode($res), True);
	
		$userid = $response['id'];
		$username = $response['name'];
		$last_activity = $response['last_activity'];
		$auth_token = $response['auth_token'];
		
		$app_token = $_POST['App_Token'];
		$email = $_POST['Email'];
		$password = $_POST['Password'];
		$array = array(
			'App_Token' => $app_token,
			'Hubstaff-Email' => $email,
			'Hubstaff-Userid' => $userid,
			'Hubstaff-Last-Activity' => $last_activity,
			'Hubstaff-AuthToken' => $auth_token,
			'Hubstaff-Username' => $username,
		);
		
		$responsearray = json_encode($array);
				
		$request->session()->put('hubstaff_userid', $userid);
		$request->session()->put('hubstaff_username', $username);
		$request->session()->put('hubstaff_last_activity', $last_activity);
		$request->session()->put('hubstaff_auth_token', $auth_token);
		$request->session()->put('hubstaff_app_token', $app_token);
		$request->session()->put('hubstaff_email', $email);
		$request->session()->put('hubstaff_password', $password);

		return response()->json($responsearray, 201);
	}
	
	/* Organization Details API Call */
	public function getAllOrganizationDetails(Request $request)
	{			
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);

		$result = $hubstaff->getRepository('organization')->getAllOrgs();
   				
   		return response()->json($result, 201);	
	}
	
	/* User Project List API Call */
	public function getProjectList(Request $request)
	{		
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);
		$result = $hubstaff->getRepository('project')->getAllProjects();
		
		return response()->json($result, 201);		
	}
	
	/* Retrieve custom my report grouped by date API Call */
	public function getProjectTaskList(Request $request)
	{
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);
		
		$Huff_Api_Url = config('constants.Huff_Api_Url');
		
		$start_date = $request->input('start_date');
		$end_date = $request->input('end_date');
		$organizationid = $request->input('organizationid');
		$projects = $request->input('projects');
		$show_tasks = $request->input('show_tasks');
		$show_notes = $request->input('show_notes');
		$show_activity = $request->input('show_activity');
		$include_archived = $request->input('include_archived');
		$users = $request->session()->get('hubstaff_userid');
		
		$curl = new Curl();
		$curl->setHeader('App-Token', $app_token);
		$curl->setHeader('Auth-Token', $auth_token);
		$url = $Huff_Api_Url.'custom/by_date/my?start_date='.$start_date.'&end_date='.$end_date.'&organizations='.$organizationid.'&projects='.$projects.'&users='.$users.'&show_tasks='.$show_tasks.'&show_notes='.$show_notes.'&show_activity='.$show_activity.'&include_archived='.$include_archived;
		
		$curl->get($url, array());
		if ($curl->error) {
			$response = array('Status'=>'400', 'Message'=>$curl->error_code);
		}
		else {
			$response = json_decode($curl->response);
		}

		$curl->close();
		$array = json_decode(json_encode($response), True);
		return response()->json($array, 201);
	}
	
	/* Get Task Time API Call */
	public function getTaskTime(Request $request)
	{		
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);
		
		$Huff_Api_Url = config('constants.Huff_Api_Url');
		
		$start_date = $request->input('start_date');
		$end_date = $request->input('end_date');
		$organizationid = $request->input('organizationid');
		$projects = $request->input('projects');
		$show_tasks = $request->input('show_tasks');
		$show_notes = $request->input('show_notes');
		$show_activity = $request->input('show_activity');
		$include_archived = $request->input('include_archived');
		$users = $request->session()->get('hubstaff_userid');
		
		$tot = '0';   			
		$curl = new Curl();
		$curl->setHeader('App-Token', $app_token);
		$curl->setHeader('Auth-Token', $auth_token);
		$url = $Huff_Api_Url.'custom/by_date/my?start_date='.$start_date.'&end_date='.$end_date.'&organizations='.$organizationid.'&projects='.$projects.'&users='.$users.'&show_tasks='.$show_tasks.'&show_notes='.$show_notes.'&show_activity='.$show_activity.'&include_archived='.$include_archived;

		$curl->get($url, array());
		if ($curl->error) {
			$response = array('Status'=>'400', 'Message'=>$curl->error_code);
		}
		else {
			$response = json_decode($curl->response);
		}

		$curl->close();
		$ar=array();
		$toth = 0; 
		$organizations=$response->organizations;
		foreach ($organizations as $org) {
			$dates = $org->dates;
			foreach($dates as $com){
				 $user = $com->users;
				 foreach($user as $us){
					$proj = $us->projects;
					 foreach($proj as $task){
						$tasks = $task->tasks;						
						foreach($tasks as $task){
							$sec = $task->duration;
							$totht[] = $sec;
							$ech = $sec/60;
							$tot = $ech+$tot;
							$tot = round($tot);
							$time = date('H:i', mktime(0,$ech));
							$a[] = array(
								'taskid' => $task->id,
								'summary' => $task->summary,
								'remote_id' => $task->remote_id,
								'remote_alternate_id' => $task->remote_alternate_id,
								'duration' => $time, 
							);
						}
					 }
				 }

			}

		}
		$kl = array_sum($totht);		
		$array = json_decode(json_encode($a), True);
		$tasklist = $array;
		$total_hours = $this->get_time($kl);
		$responsedata['tasklist'] = $tasklist;
		$responsedata['total_hours'] = $total_hours;
		return response()->json($responsedata, 201);	
	}
	
	public function get_time($time) {
		$duration = $time;
		$hours = floor($duration / 3600);
		$minutes = floor(($duration / 60) % 60);
		$seconds = $duration % 60;
		if ($hours != 0){
			return "$hours:$minutes:$seconds";
		}
		else{
			return "$minutes:$seconds";
		}
	}

	
	
	public function addDurationAsSeconds($timeStamp) {
        $timeSections = explode( ':', $timeStamp );	
        $seconds[] = ( ( $timeSections[0] * 3600 )      //Hours to Seconds
                 +  ( $timeSections[1] * 60 ));       //Minutes to Seconds     
        return $seconds;
    }
	
	/* Get Task List API Call */
	public function getTaskList(Request $request)
	{
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);
		$projectIds = $request->input('projects');
		$offset = 0;
		
		$Huff_Api_Url = config('constants.Huff_Api_Url');
		
		$curl = new Curl();
        $curl->setHeader('App-Token', $app_token);
        $curl->setHeader('Auth-Token', $auth_token);
		$url = $Huff_Api_Url.'tasks?projects='.$projectIds.'&offset=0';
		
		$curl->get($url, array());
		 if ($curl->error) {
			$response = array('Status'=>'400', 'Message'=>$curl->error_code);
		}
		else {
			$response = json_decode($curl->response);
		}

		$curl->close();
		$array = json_decode(json_encode($response), True);        
        return response()->json($array, 201);		
	}
	/* Get Task Details API Call */
	public function getTask(Request $request)
	{
		$auth_token = $request->session()->get('hubstaff_auth_token');
		$app_token = $request->session()->get('hubstaff_app_token'); 
		$email = $request->session()->get('hubstaff_email'); 
		$email = $request->session()->get('hubstaff_email'); 
		$password = $request->session()->get('hubstaff_password');

		$hubstaff = Hubstaff::getInstance();
		$hubstaff->authenticate($app_token, $email, $password, $auth_token);
		$taskid = $request->input('taskid');
		$offset = 0;
		
		$Huff_Api_Url = config('constants.Huff_Api_Url');
		
		$curl = new Curl();
        $curl->setHeader('App-Token', $app_token);
        $curl->setHeader('Auth-Token', $auth_token);
		$url = $Huff_Api_Url.'tasks/'.$taskid;
		
		$curl->get($url, array());
		 if ($curl->error) {
			$response = array('Status'=>'400', 'Message'=>$curl->error_code);
		}
		else {
			$response = json_decode($curl->response);
		}
		$curl->close();
		$array = json_decode(json_encode($response), True);        
        return response()->json($array, 201);		
	}
	
  }













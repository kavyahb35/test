<?php
namespace App\Http\Controllers;
use App\Appmodel;
use Illuminate\Http\Request;
use DB;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UsersController extends Controller {
	
	/* Authentication API Call */
    public function authenticate(Request $request)
	{
        $tag = new Appmodel();
        $Email = $request->input('Email');
        $Password = $request->input('Password');
		$Admin_Email = config('constants.Admin_Email');
        if((!empty($Email)) && (!empty($Password))){
			$encPassword = base64_encode($Password);
			$Emailcheck = $tag->checkEmailValidate($Email);   
			if($Emailcheck == '1'){
				if($Email == $Admin_Email){
				   $employee = DB::table('hruserlogins')->where('LoginProvider',$Email)->where("ProviderKey",$encPassword)->where("Status",'1')->get();		  
					if (empty($employee)){
						$data=array('Status'=>'400', 'Message'=>'Unauthenticate User.');
					}else{
						foreach ($employee as $svalue) {
							$Email = $svalue->LoginProvider;                
							$Name=$svalue->ProviderDisplayName;
							$Id=$svalue->UserId;
							$Status=$svalue->Status;
							$Key=mt_rand();
							DB::table('hruserlogins')
							->where('UserId', $Id)
							->update(array('Accesstoken' => $Key));

							$request->session()->put('Loginemail', $Email);
							$request->session()->put('loginname', $Name);
							$request->session()->put('LoginId', $Id);
							$request->session()->put('Status', $Status);
							$userdetail=array(
							   'ID'=>$Id,
							   'Email'=>$Email,
							   'Username'=>$Name,
							   'Status'=>$svalue->Status,
							   'Accesstoken'=>$Key,
							 );
							 $data=array('Status'=>'200', 'Message'=>'Login successfully.', 'Userdetail'=>$userdetail);
						}    
					}
				}else{
					$encPassword=base64_encode($Password);
					$employee = DB::table('hruserlogins')->where('LoginProvider',$Email)->where("ProviderKey",$encPassword)->get();
		  
					if (empty($employee)){
						$data=array('Status'=>'400', 'Message'=>'Unauthenticate User.');
					}else{
						foreach ($employee as $svalue) {
						$Email=$svalue->LoginProvider;                
						$Name=$svalue->ProviderDisplayName;
						$Id=$svalue->UserId;
						$Status=$svalue->Status;
						$Key=mt_rand();
						DB::table('hruserlogins')
							->where('UserId', $Id)
							->update(array('Accesstoken' => $Key)); 

						$request->session()->put('Loginemail', $Email);
						$request->session()->put('loginname', $Name);
						$request->session()->put('LoginId', $Id);
						$request->session()->put('Status', $Status);
						$userdetail=array(
							'ID'=>$Id,
							'Email'=>$Email,
							'Username'=>$Name,
							'Status'=>$svalue->Status,
							'Accesstoken'=>$Key,
						);
						$data=array('Status'=>'200', 'Message'=>'Login successfully.', 'Userdetail'=>$userdetail);
					 } 
				  }
				}          
			}else{
			   $data=array('Status'=>'400', 'Message'=>'Invalid Email Id');
			}
        }else{
			$data=array('Status'=>'400', 'Message'=>'All Fields required');
        }
        return response()->json($data, 201);
    }
	/* User Create API Call */
    public function usersCreate(Request $request)
	{      
        $Email = $request->input('Email');
        $Role = $request->input('Role');
        $Accesskey = $request->input('AccessKey');
        $error = '';

        $tag = new Appmodel();
        $Checkkey = $tag->authenticateAPI($Accesskey);      
       
        if($Checkkey!=''){ 
			if((!empty($Email)) && (!empty($Role)) && (!empty($Accesskey))){
            
            $EmailCheck = $tag->checkEmailValidate($Email);          
            $EmailExist = $tag->checkEmailExist($Email);
            if($EmailCheck == '1' && $EmailExist == '0'){
                $parts = explode('@', $Email);
                $uname = $parts[0];
				$Userid = DB::table('hrusers')->insertGetId(
					   array('Email' => $Email,
							 'UserStatus' => $Role,
							 'Status' => '3',
							 'UserName' => $Email,
							 )
					);

				$userid_login = DB::table('hruserlogins')->insertGetId(
					   array('LoginProvider' => $Email,
							 'ProviderDisplayName' => $Email,
							 'UserId' => $Userid,
							 'Status' => '3',
							 )
					);


				DB::table('hrusers')
				  ->where('id', $Userid)
				  ->update(array('UserId' => $Userid)); 
					$Api_Url = config('constants.Api_Url');
					$url= $Api_Url.'v1/users/reset-password/'.$Userid; 
					$toemail = $Email;
					$subject = "User Login Details";

					/*$message = "
						<html>
						<head>
						<title>Login Details</title>
						</head>
						<body>
						<table border='1'>
						<tr>
						<th>Email : ".$Email." </th>
						<th> Reset Password Link : <a href='".$url."' target='_blank'>Reset Password</a></th>
						</tr>
						</table>
						</body>
						</html>
					";

					// Always set content-type when sending HTML email
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
					$Form_Email = config('constants.Form_Email');
					// More headers
					$headers .= 'From: <'.$Form_Email.'>' . "\r\n";

					mail($toemail,$subject,$message,$headers);
					*/
					$userdetail = array(
								  'Email' => $Email,
								  'UserID' => $Userid
							    );

					$error = array('Status' => "200", "Message" => "Insert Successfully","Userdetail" => $userdetail);
				  
				}else{					
					if($ems=='1'){
						$error = array('Status' => "400", "Message" => "Email ID already Exist ");
					} else{
						$error = array('Status' => "400", "Message" => "Invalid Email format");
					}
				}
			}
          else{
			$error=array('Status'=>'400', 'Message'=>'All Fields required');
          }
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);        
    }
   
	/* Get User List API Call */
    public function getUsers(REQUEST $request)
	{
        $Accesskey = $request->input('AccessKey');
        $tag = new Appmodel();
        $check = $tag->authenticateAPI($Accesskey);
        $check = '1';
        if($check=='1'){
			$uses = DB::select('select * from hrusers');            
			foreach($uses as $userrecord){
				$img=$userrecord->ProfileImage;
				$Api_Url = config('constants.Api_Url');
				if($img!=''){
					$image = $Api_Url.'public/images/'.$img;
				}else{
				   $image = $Api_Url.'public/images/dummy.jpg';
				}
				$maried=$userrecord->MaritalStatus;
				if($maried=='1'){ $m='married';}else{ $m='single';}
					$users[]=array(
						'Id'=>$userrecord->Id,
						'Email'=>$userrecord->Email,
						'FirstName'=>$userrecord->FirstName,
						'LastName'=>$userrecord->LastName,
						'PersonalEmail'=>$userrecord->PersonalEmail,
						'NormalizedUserName'=>$userrecord->NormalizedUserName,
						'ReferencePhoneNumber'=>$userrecord->ReferencePhoneNumber,
						'PhoneNumber'=>$userrecord->PhoneNumber,
						'BirthDate'=>$userrecord->BirthDate,
						'AnniversaryDate'=>$userrecord->AnniversaryDate,
						'EmergencyContactPerson'=>$userrecord->EmergencyContactPerson,
						'BloodGroup'=>$userrecord->BloodGroup,
						'FacebookId'=>$userrecord->FacebookId,
						'FacebookPageLike'=>$userrecord->FacebookPageLike,
						'LinkedIn'=>$userrecord->LinkedIn,
						'Address'=>$userrecord->Address,
						'UserStatus'=>$userrecord->UserStatus,
						'UserId'=>$userrecord->UserId,
						'ProfileImage'=>$image,
						'Gender'=>$userrecord->Gender,'MaritalStatus'=>$m,'SpouseName'=>$userrecord->SpouseName,'Relation'=>$userrecord->ContactRelation,'SpouseContact'=>$userrecord->SpouseContact,
					);
            }
            $error=array('Status'=>'200', 'Users'=>$users);

        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);  
    }

    /* Get User Details API Call */
    public function getUsersDetail($id)
	{       
        $Check = '1';
        if($Check == '1'){
			$uses = DB::select('select * from hrusers where UserId = ?',[$id]);
			if(!empty($uses)){
				foreach($uses as $userdetail){
					$img=$userdetail->ProfileImage;
					$Api_Url = config('constants.Api_Url');
					
					if($img!=''){
						$image = $Api_Url.'public/images/'.$img;
					}else{
						$image = $Api_Url.'public/images/dummy.jpg';
					}
					$maried=$userdetail->MaritalStatus;
					if($maried=='1'){ $m='married';}else{ $m='single';}
					$users[]=array(
						'Id'=>$userdetail->Id,
						'Email'=>$userdetail->Email,
						'FirstName'=>$userdetail->FirstName,
						'LastName'=>$userdetail->LastName,
						'PersonalEmail'=>$userdetail->PersonalEmail,
						'NormalizedUserName'=>$userdetail->NormalizedUserName,
						'ReferencePhoneNumber'=>$userdetail->ReferencePhoneNumber,
						'PhoneNumber'=>$userdetail->PhoneNumber,
						'BirthDate'=>$userdetail->BirthDate,
						'AnniversaryDate'=>$userdetail->AnniversaryDate,
						'EmergencyContactPerson'=>$userdetail->EmergencyContactPerson,
						'BloodGroup'=>$userdetail->BloodGroup,
						'FacebookId'=>$userdetail->FacebookId,
						'FacebookPageLike'=>$userdetail->FacebookPageLike,
						'LinkedIn'=>$userdetail->LinkedIn,
						'Address'=>$userdetail->Address,
						'UserStatus'=>$userdetail->UserStatus,
						'UserId'=>$userdetail->UserId,
						'ProfileImage'=>$image,
						'Gender'=>$userdetail->Gender,'MaritalStatus'=>$m,'SpouseName'=>$userdetail->SpouseName,'Relation'=>$userdetail->ContactRelation,'SpouseContact'=>$userdetail->SpouseContact,
					);
				}
				$error=array('Status'=>'200', 'Users'=>$users);
			}else{
				$error=array('Status'=>'400', 'Message'=>'User Not Exist');
			}
        }else{
          $error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
         return response()->json($error, 201);  
    }   
	
   /* Delete User API Call */
    public function deleteUser(Request $request,$id)
	{     
        //$accesskey = $request->input('AccessKey');       
        $tag = new Appmodel();
        $Checkkey =$tag->authenticateAPI($accesskey);
        $Checkkey = '1';
        if($Checkkey == '1'){
			$users = DB::select('select * from hrusers where UserId = ?',[$id]);
            if(!empty($users)){
				DB::table('hruserlogins')
				->where('UserId', $id)
				->update(array('Status' => '2')); 
				$error=array('Status'=>'200', 'Message'=>'User inactive Successfully.');
			}else{
			   $error=array('Status'=>'400', 'Message'=>'User not exist.');
			}
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
         return response()->json($error, 201);
    }

	/* Forgot Password API Call */
    public function forgotPassword(Request $request)
	{
        $Emailid = $request->input('Email');
        $tag = new Appmodel();
        $emailvalidate = $tag->checkEmailValidate($Emailid); 
        if($emailvalidate == '1'){
            $users = DB::select('select * from hrusers where Email = ?',[$Emailid]);
            if(!empty($users)){
				$uid=$users[0]->Id; 
				if($uid!=''){
					$Api_Url = config('constants.Api_Url');
					$Form_Email = config('constants.Form_Email');
					$url = $Api_Url.'v1/users/reset-password/'.$uid;                
					
					$toemail = $Emailid;
					$subject = "Reset Password - TrackIt";
					$message = "Reset Password Url : ".$url;

					// Always set content-type when sending HTML email
					$headers = "MIME-Version: 1.0" . "\r\n";
					$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

					// More headers
					$headers .= 'From: <'.$Form_Email.'>' . "\r\n";

					/*mail($toemail,$subject,$message,$headers);*/
					 
					$data['url']=$url;
					$data['success']='1';
					$error=array('Status'=>'200', 'Message'=>'Send email successfully. please check your mail','url'=>$url);
					 
				}
            }else{
                $error=array('Status'=>'400', 'Message'=>'Email Id not Exist');
            }    
         }else{
          $error=array('Status'=>'400', 'Message'=>'Email Id not valid');
        }
         return response()->json($error, 201);
        
    }

    /* Reset Password API Call */
	public function resetPassword(Request $request,$id)
	{       
        $Newpassword = $request->input('newpassword');
        $Confirmpassword = $request->input('confirmpassword');
        
        if($id!=''){          
			if(($Newpassword!='' && $Confirmpassword!='')|| ($Newpassword!='' || $Confirmpassword!='')){
				$Newpassword = base64_encode($request->input('newpassword'));
				$Confirmpassword = base64_encode($request->input('confirmpassword'));
				$users = DB::select('select * from hrusers where UserId = ?',[$id]);
				if(!empty($users)){
					if($Newpassword==$Confirmpassword){						
						DB::table('hrusers')
						  ->where('UserId', $id)
						  ->update(array('PasswordHash' => $Newpassword,
						));
						DB::table('hruserlogins')
						  ->where('UserId', $id)
						  ->update(array('ProviderKey' => $Newpassword,
						));
						$error=array('Status'=>'200', 'Message'=>'Reset password successfully.Please Login with new password');
					}else{
						$error=array('Status'=>'400', 'Message'=>'Password and Confirm password does not match');
					}
				}else{
					$error=array('Status'=>'400', 'Message'=>'User not Exist');
				}
			}else{
				$error=array('Status'=>'400', 'Message'=>'All Fields required');
			}
             
        }else{
             $error=array('Status'=>'400', 'Message'=>'User not Exist');
        }
       $data['id']=$id;
        return response()->json($error, 201);
    }

   
	/* After Login change password API Call */
    public function changePassword(Request $request)
	{        
        $OldPassword = $request->input('oldPassword');
        $NewPassword = $request->input('newPassword');
        
        $LoginId = $request->input('Accesstoken');
        $accesskey = $request->input('AccessKey');
       
        $tag = new Appmodel();
        $chk =$tag->authenticateAPI($accesskey);
        $chk='1';
        if($chk=='1'){       
			if($OldPassword!='' && $NewPassword!=''){
				$encPassword=base64_encode($OldPassword);
				$emp = DB::table('hruserlogins')->where('Accesstoken',$LoginId)->where("ProviderKey",$encPassword)->get();
				if(!empty($emp)){					
					$NewPassword=base64_encode($NewPassword);
					DB::table('hrusers')
					->where('UserId', $emp[0]->UserId)
					->update(array('PasswordHash' => $NewPassword,
					));
					DB::table('hruserlogins')
					->where('UserId', $emp[0]->UserId)
					->update(array('ProviderKey' => $NewPassword,
					));
					$error=array('Status'=>'200', 'Message'=>'Change Password successfully.');					
				}else{
					$error=array('Status'=>'400', 'Message'=>'Old Password does not match.');
				}
			}else{
				$error=array('Status'=>'400', 'Message'=>'All fields required.');
				
			}
        }else{
            $error=array('Status'=>'400', 'Message'=>'Unauthenticate user.');
        }
       return response()->json($error, 201);
    }

	/* Edit User API Call */
	public function editUser(Request $request,$id)
	{
		$FirstName = $request->input('FirstName');
		$LastName = $request->input('LastName');
		$PersonalEmail = $request->input('PersonalEmail');
		$NormalizedUserName = $request->input('NormalizedUserName');
		$PhoneNumber = $request->input('PhoneNumber');
		$ReferencePhoneNumber = $request->input('ReferencePhoneNumber');
		$BirthDate = date("Y-m-d", strtotime($request->input('BirthDate')));
		$AnniversaryDate = date("Y-m-d", strtotime($request->input('AnniversaryDate')));
		$EmergencyContactPerson = $request->input('EmergencyContactPerson');
		$BloodGroup = $request->input('BloodGroup');
		$FacebookId = $request->input('FacebookId');
		$FacebookPageLike = $request->input('FacebookPageLike');
		$LinkedIn = $request->input('LinkedIn');
		$Address = $request->input('Address');
		$Gender = $request->input('Gender');
		$MaritalStatus = $request->input('MaritalStatus');
		$SpouseName = $request->input('SpouseName');
		$SpouseContact = $request->input('SpouseContact');
		$Relation= $request->input('Relation');

		$adminId = $request->session()->get('LoginId');
		$accesskey = $request->input('AccessKey');
       
        $tag = new Appmodel();
        $Checkkey =$tag->authenticateAPI($accesskey);
        $Checkkey='1';
        if($Checkkey=='1'){

          if((!empty($FirstName)) && (!empty($LastName)) && (!empty($Gender)) && (!empty($PhoneNumber)) && (!empty($BirthDate)) && (!empty($Address))){
				$Emailvalidate = $tag->checkEmailValidate($PersonalEmail);   
				if($Emailvalidate == '1'){
                 $users = DB::select('select * from hrusers where UserId = ?',[$id]);
                 if(!empty($users)){
                    
                    $image = $request->file('ProfileImage');
					$image = $request->file('ProfileImage');
                    DB::table('hruserlogins')
						->where('UserId', $id)
						->update(array('Status' => '0',
                    ));
                    if($image==''){
						DB::table('hrusers')
                            ->where('UserId', $id)
                            ->update(array('FirstName' => $FirstName,
							   'LastName' => $LastName,
							   'PersonalEmail' => $PersonalEmail,
							   'NormalizedUserName' => $NormalizedUserName,
							   'PhoneNumber' => $PhoneNumber,
							   'ReferencePhoneNumber' => $ReferencePhoneNumber,
							   'BirthDate' => $BirthDate,
							   'AnniversaryDate' => $AnniversaryDate,
							   'EmergencyContactPerson' => $EmergencyContactPerson,
							   'BloodGroup' => $BloodGroup,
							   'FacebookId' => $FacebookId,
							   'FacebookPageLike' => $FacebookPageLike,
							   'LinkedIn' => $LinkedIn,
							   'Address' => $Address,
							   'Gender' => $Gender,
							   'MaritalStatus' => $MaritalStatus,
							   'SpouseName' => $SpouseName,
							   'SpouseContact' => $SpouseContact,
								'ContactRelation' => $Relation,'Status'=>'0',
							));

                    }else{
                        $input['imagename'] = time().'.'.$image->getClientOriginalExtension();
                        $destinationPath = public_path('/images');
                        $image->move($destinationPath, $input['imagename']);
					 
						if($image!=''){
							$img=$input['imagename'];
							DB::table('hrusers')
							->where('UserId', $id)
							->update(array('FirstName' => $FirstName,
								'LastName' => $LastName,
								'PersonalEmail' => $PersonalEmail,
								'NormalizedUserName' => $NormalizedUserName,
								'PhoneNumber' => $PhoneNumber,
								'ReferencePhoneNumber' => $ReferencePhoneNumber,
								'BirthDate' => $BirthDate,
								'AnniversaryDate' => $AnniversaryDate,
								'EmergencyContactPerson' => $EmergencyContactPerson,
								'BloodGroup' => $BloodGroup,
								'FacebookId' => $FacebookId,
								'FacebookPageLike' => $FacebookPageLike,
								'LinkedIn' => $LinkedIn,
								'Address' => $Address,
								'ProfileImage'=>$img,
								'Gender' => $Gender,
								'MaritalStatus' => $MaritalStatus,
								'SpouseName' => $SpouseName,
								'SpouseContact' => $SpouseContact,
								'ContactRelation' => $Relation,'Status'=>'0',
							));

						}else{
							DB::table('hrusers')
							->where('UserId', $id)
							->update(array('FirstName' => $FirstName,
								'LastName' => $LastName,
								'PersonalEmail' => $PersonalEmail,
								'NormalizedUserName' => $NormalizedUserName,
								'PhoneNumber' => $PhoneNumber,
								'ReferencePhoneNumber' => $ReferencePhoneNumber,
								'BirthDate' => $BirthDate,
								'AnniversaryDate' => $AnniversaryDate,
								'EmergencyContactPerson' => $EmergencyContactPerson,
								'BloodGroup' => $BloodGroup,
								'FacebookId' => $FacebookId,
								'FacebookPageLike' => $FacebookPageLike,
								'LinkedIn' => $LinkedIn,
								'Address' => $Address,
								'Gender' => $Gender,
								'MaritalStatus' => $MaritalStatus,
								'SpouseName' => $SpouseName,
								'SpouseContact' => $SpouseContact,
								'ContactRelation' => $Relation,'Status'=>'0',
							));
                        }
					}
                    
                    $uses = DB::select('select * from hrusers where UserId = ?',[$id]);
                    foreach($uses as $user){
						$img=$user->ProfileImage;
						$Api_Url = config('constants.Api_Url');
						if($img!=''){
							$image = $Api_Url.'public/images/'.$img;
						}else{
							$image = $Api_Url.'public/images/dummy.jpg';
						}
						if($user->MaritalStatus=='1'){ $m='married';}else{ $m='Single';}
						$users=array(
							'Id'=>$user->Id,
							'Email'=>$user->Email,
							'FirstName'=>$user->FirstName,
							'LastName'=>$user->LastName,
							'PersonalEmail'=>$user->PersonalEmail,
							'NormalizedUserName'=>$user->NormalizedUserName,
							'ReferencePhoneNumber'=>$user->ReferencePhoneNumber,
							'PhoneNumber'=>$user->PhoneNumber,
							'BirthDate'=>$user->BirthDate,
							'AnniversaryDate'=>$user->AnniversaryDate,
							'EmergencyContactPerson'=>$user->EmergencyContactPerson,
							'BloodGroup'=>$user->BloodGroup,
							'FacebookId'=>$user->FacebookId,
							'FacebookPageLike'=>$user->FacebookPageLike,
							'LinkedIn'=>$user->LinkedIn,
							'Address'=>$user->Address,
							'UserStatus'=>$user->UserStatus,
							'UserId'=>$user->UserId,
							'ProfileImage'=>$image,
							'Gender' => $user->Gender,
							'MaritalStatus' => $m,
							'SpouseName' => $user->SpouseName,
							'SpouseContact' => $user->SpouseContact,
							'Relation' => $user->ContactRelation
						);

                    }
					$error=array('Status'=>'200', 'Message'=>'Update details Successfully','Userdetail'=>$users);
                 }else{
                    $error=array('Status'=>'400', 'Message'=>'User not exist');
                 }
               }else{
                  $error=array('Status'=>'400', 'Message'=>'Invalid Email Id formate');
               }  
          }else{
            $error=array('Status'=>'400', 'Message'=>'All fields required');
          }
        }else{
          $error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);   
    }

	
	/* User history Log API Call */
    public function historyLog(Request $request,$id)
	{      
        //$accesskey = $request->input('AccessKey');       
        //$tag = new Appmodel();
        //$chk =$tag->authenticateAPI($accesskey);
        $Checkkey = '1';
        if($Checkkey == '1'){ 
			$users = DB::table('hremployeehistryold')->where('UserId',$id)->orderBy('Id', 'desc')->get();
			if(empty($users)){
				$error=array('Status'=>'200', 'Message'=>'Empty logs','Userdetails'=>$users);
			}else{				 
				foreach($users as $user){					  
					$img=$user->ProfileImage;
					$Api_Url = config('constants.Api_Url');
					if($img!=''){
						$image = $Api_Url.'public/images/'.$img;
					}else{
						$image = $Api_Url.'public/images/dummy.jpg';
					}
					$usersde[]=array(
						'UserId'=>$user->UserId,
						'PersonalEmail'=>$user->PersonalEmail,
						'FirstName'=>$user->FirstName,
						'LastName'=>$user->LastName,
						'PhoneNumber'=>$user->PhoneNumber,
						'ReferencePhoneNumber'=>$user->ReferencePhoneNumber,
						'BirthDate'=>$user->BirthDate,
						'AnniversaryDate'=>$user->AnniversaryDate,
						'EmergencyContactNo'=>$user->EmergencyContactNo,
						'BloodGroup'=>$user->BloodGroup,
						'FacebookId'=>$user->FacebookId,
						'FacebookPageLike'=>$user->FacebookPageLike,
						'LinkedIn'=>$user->LinkedIn,
						'Address'=>$user->Address,
						'Created'=>$user->Created,
						'ProfileImage'=>$image,
					);
				}
				$error=array('Status'=>'200', 'Message'=>'User logs','Userdetails'=>$usersde);			  
			}
          }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }         
       return response()->json($error, 201);
    }

	/* All Users history Log API Call */
    public function historyLogAllusers(Request $request)
    {
        //$accesskey = $request->input('AccessKey');       
		// $tag = new Appmodel();
        //$chk =$tag->authenticateAPI($accesskey);
        $Checkkey = '1';
        if($Checkkey == '1'){
			$users =DB::select('select * from hremployeehistryold ');
			if(empty($users)){
			  $error=array('Status'=>'200', 'Message'=>'Empty logs','Userdetails'=>$users);
			}else{             
				foreach($users as $user){
					$img=$user->ProfileImage;
					$Api_Url = config('constants.Api_Url');
					if($img!=''){
						$image = $Api_Url.'public/images/'.$img;
					}else{
						$image = $Api_Url.'public/images/dummy.jpg';
					}
					$usersde[]=array(
						'UserId'=>$user->UserId,
						'PersonalEmail'=>$user->PersonalEmail,
						'FirstName'=>$user->FirstName,
						'LastName'=>$user->LastName,
						'PhoneNumber'=>$user->PhoneNumber,
						'ReferencePhoneNumber'=>$user->ReferencePhoneNumber,
						'BirthDate'=>$user->BirthDate,
						'AnniversaryDate'=>$user->AnniversaryDate,
						'EmergencyContactNo'=>$user->EmergencyContactNo,
						'BloodGroup'=>$user->BloodGroup,
						'FacebookId'=>$user->FacebookId,
						'FacebookPageLike'=>$user->FacebookPageLike,
						'LinkedIn'=>$user->LinkedIn,
						'Address'=>$user->Address,
						'Created'=>$user->Created,
						'ProfileImage'=>$i,
					);
				}
				$error=array('Status'=>'200', 'Message'=>'User logs','Userdetails'=>$usersde);          
			}
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);   
   } 

	/* Task reason API Call */
	public function taskReason(Request $request,$id)
	{      
        $ProjectID = $request->input('ProjectID');
        $TaskID = $request->input('TaskID');
        $Starttime = $request->input('StartTime');
        $Endtime = $request->input('EndTime');
        $Reason = $request->input('Reason');
        $accesskey = $request->input('AccessKey');
		$Taskdate = $request->input('TaskDate');
        $dating=date('Y-m-d H:i:s');
        $error = '';

        $tag = new Appmodel();
        $Checkkey =$tag->authenticateAPI($accesskey);
      
        //$Checkkey = '1';
        if($Checkkey == '1'){ 
			if((!empty($ProjectID))  && (!empty($Endtime)) && (!empty($Reason)) && (!empty($accesskey)) && (!empty($TaskID)) && (!empty($Starttime))){            
				$s=$Taskdate.' '.$Starttime;
				$e=$Taskdate.' '.$Endtime ;
				$start = strtotime($s);
				$end   = strtotime($e);
				$diff  = $end - $start;

				$hours = floor($diff / (60 * 60));
				$minutes = $diff - $hours * (60 * 60);

				$respo = $hours.':'.floor( $minutes / 60 );
				$to = DB::table('tasktime')->insertGetId(
				   array('UserId' => $id,
						 'ProjectId' => $ProjectID,
						 'TaskId' => $TaskID,
						 'StartTime' => $Starttime,
						 'EndTime' => $Endtime,
						 'Reason' => $Reason,
						 'Created' => $dating,
						 'Approved' => '0','TaskDate'=>$Taskdate,'DiscardedTime'=>$respo,
						 )
				);
				$userdetail= array('UserId' => $id,
						 'ProjectId' => $ProjectID,
						 'TaskId' => $TaskID,
						 'StartTime' => $Starttime,
						 'EndTime' => $Endtime,
						 'Reason' => $Reason,
						 'Created' => $dating,
						 'Approved' => '0','TaskDate'=>$Taskdate,'DiscardedTime'=>$respo,
						 );
                $error = array('Status' => "200", "Message" => "Insert Successfully","Userdetail" => $userdetail);           
          }
          else{
            $error=array('Status'=>'400', 'Message'=>'All Fields required');
          }
        }else{
          $error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);        
    }

	/* Task List API Call */
	public function taskList(Request $request,$id)
	{			   
        $accesskey = $request->input('AccessKey');		
        $error = '';
        $tag = new Appmodel();
        $Checkkey = $tag->authenticateAPI($accesskey);      
        if($Checkkey == '1'){ 
			$users = DB::select('select * from tasktime where UserId = ?',[$id]);
            $error = array('Status' => "200", "Manual-timer" => $users);
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);   
	}

	/* Delete Task time API Call */
	public function deleteTime(Request $request,$id)
	{   
        $Checkkey='1';
        if($Checkkey=='1'){
			DB::delete('delete from tasktime  where Id= ?',[$id]);
            $error=array('Status'=>'200', 'Message'=>'Delete time Successfully.');
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);
    }

	/* Task list by date API Call */
	public function taskListDate(Request $request,$id,$time)
	{
        $error = '';
        $Checkkey = '1';
        if($Checkkey == '1'){ 
			$users = DB::table('tasktime')->where('UserId',$id)->where("TaskDate",$time)->get();
            $error = array('Status' => "200", "Manual-timer" => $users);          
        }else{
			$error=array('Status'=>'400', 'Message'=>'Unauthenticate Users');
        }
        return response()->json($error, 201);   
	}

  }












